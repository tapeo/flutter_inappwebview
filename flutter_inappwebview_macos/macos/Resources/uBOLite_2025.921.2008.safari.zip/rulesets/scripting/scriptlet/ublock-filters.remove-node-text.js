/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*/

// ruleset: ublock-filters

// Important!
// Isolate from global scope

// Start of local scope
(function uBOL_removeNodeText() {

/******************************************************************************/

function removeNodeText(
    nodeName,
    includes,
    ...extraArgs
) {
    replaceNodeTextFn(nodeName, '', '', 'includes', includes || '', ...extraArgs);
}

function replaceNodeTextFn(
    nodeName = '',
    pattern = '',
    replacement = ''
) {
    const safe = safeSelf();
    const logPrefix = safe.makeLogPrefix('replace-node-text.fn', ...Array.from(arguments));
    const reNodeName = safe.patternToRegex(nodeName, 'i', true);
    const rePattern = safe.patternToRegex(pattern, 'gms');
    const extraArgs = safe.getExtraArgs(Array.from(arguments), 3);
    const reIncludes = extraArgs.includes || extraArgs.condition
        ? safe.patternToRegex(extraArgs.includes || extraArgs.condition, 'ms')
        : null;
    const reExcludes = extraArgs.excludes
        ? safe.patternToRegex(extraArgs.excludes, 'ms')
        : null;
    const stop = (takeRecord = true) => {
        if ( takeRecord ) {
            handleMutations(observer.takeRecords());
        }
        observer.disconnect();
        if ( safe.logLevel > 1 ) {
            safe.uboLog(logPrefix, 'Quitting');
        }
    };
    const textContentFactory = (( ) => {
        const out = { createScript: s => s };
        const { trustedTypes: tt } = self;
        if ( tt instanceof Object ) {
            if ( typeof tt.getPropertyType === 'function' ) {
                if ( tt.getPropertyType('script', 'textContent') === 'TrustedScript' ) {
                    return tt.createPolicy(getRandomTokenFn(), out);
                }
            }
        }
        return out;
    })();
    let sedCount = extraArgs.sedCount || 0;
    const handleNode = node => {
        const before = node.textContent;
        if ( reIncludes ) {
            reIncludes.lastIndex = 0;
            if ( safe.RegExp_test.call(reIncludes, before) === false ) { return true; }
        }
        if ( reExcludes ) {
            reExcludes.lastIndex = 0;
            if ( safe.RegExp_test.call(reExcludes, before) ) { return true; }
        }
        rePattern.lastIndex = 0;
        if ( safe.RegExp_test.call(rePattern, before) === false ) { return true; }
        rePattern.lastIndex = 0;
        const after = pattern !== ''
            ? before.replace(rePattern, replacement)
            : replacement;
        node.textContent = node.nodeName === 'SCRIPT'
            ? textContentFactory.createScript(after)
            : after;
        if ( safe.logLevel > 1 ) {
            safe.uboLog(logPrefix, `Text before:\n${before.trim()}`);
        }
        safe.uboLog(logPrefix, `Text after:\n${after.trim()}`);
        return sedCount === 0 || (sedCount -= 1) !== 0;
    };
    const handleMutations = mutations => {
        for ( const mutation of mutations ) {
            for ( const node of mutation.addedNodes ) {
                if ( reNodeName.test(node.nodeName) === false ) { continue; }
                if ( handleNode(node) ) { continue; }
                stop(false); return;
            }
        }
    };
    const observer = new MutationObserver(handleMutations);
    observer.observe(document, { childList: true, subtree: true });
    if ( document.documentElement ) {
        const treeWalker = document.createTreeWalker(
            document.documentElement,
            NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT
        );
        let count = 0;
        for (;;) {
            const node = treeWalker.nextNode();
            count += 1;
            if ( node === null ) { break; }
            if ( reNodeName.test(node.nodeName) === false ) { continue; }
            if ( node === document.currentScript ) { continue; }
            if ( handleNode(node) ) { continue; }
            stop(); break;
        }
        safe.uboLog(logPrefix, `${count} nodes present before installing mutation observer`);
    }
    if ( extraArgs.stay ) { return; }
    runAt(( ) => {
        const quitAfter = extraArgs.quitAfter || 0;
        if ( quitAfter !== 0 ) {
            setTimeout(( ) => { stop(); }, quitAfter);
        } else {
            stop();
        }
    }, 'interactive');
}

function getRandomTokenFn() {
    const safe = safeSelf();
    return safe.String_fromCharCode(Date.now() % 26 + 97) +
        safe.Math_floor(safe.Math_random() * 982451653 + 982451653).toString(36);
}

function runAt(fn, when) {
    const intFromReadyState = state => {
        const targets = {
            'loading': 1, 'asap': 1,
            'interactive': 2, 'end': 2, '2': 2,
            'complete': 3, 'idle': 3, '3': 3,
        };
        const tokens = Array.isArray(state) ? state : [ state ];
        for ( const token of tokens ) {
            const prop = `${token}`;
            if ( Object.hasOwn(targets, prop) === false ) { continue; }
            return targets[prop];
        }
        return 0;
    };
    const runAt = intFromReadyState(when);
    if ( intFromReadyState(document.readyState) >= runAt ) {
        fn(); return;
    }
    const onStateChange = ( ) => {
        if ( intFromReadyState(document.readyState) < runAt ) { return; }
        fn();
        safe.removeEventListener.apply(document, args);
    };
    const safe = safeSelf();
    const args = [ 'readystatechange', onStateChange, { capture: true } ];
    safe.addEventListener.apply(document, args);
}

function safeSelf() {
    if ( scriptletGlobals.safeSelf ) {
        return scriptletGlobals.safeSelf;
    }
    const self = globalThis;
    const safe = {
        'Array_from': Array.from,
        'Error': self.Error,
        'Function_toStringFn': self.Function.prototype.toString,
        'Function_toString': thisArg => safe.Function_toStringFn.call(thisArg),
        'Math_floor': Math.floor,
        'Math_max': Math.max,
        'Math_min': Math.min,
        'Math_random': Math.random,
        'Object': Object,
        'Object_defineProperty': Object.defineProperty.bind(Object),
        'Object_defineProperties': Object.defineProperties.bind(Object),
        'Object_fromEntries': Object.fromEntries.bind(Object),
        'Object_getOwnPropertyDescriptor': Object.getOwnPropertyDescriptor.bind(Object),
        'Object_hasOwn': Object.hasOwn.bind(Object),
        'RegExp': self.RegExp,
        'RegExp_test': self.RegExp.prototype.test,
        'RegExp_exec': self.RegExp.prototype.exec,
        'Request_clone': self.Request.prototype.clone,
        'String': self.String,
        'String_fromCharCode': String.fromCharCode,
        'String_split': String.prototype.split,
        'XMLHttpRequest': self.XMLHttpRequest,
        'addEventListener': self.EventTarget.prototype.addEventListener,
        'removeEventListener': self.EventTarget.prototype.removeEventListener,
        'fetch': self.fetch,
        'JSON': self.JSON,
        'JSON_parseFn': self.JSON.parse,
        'JSON_stringifyFn': self.JSON.stringify,
        'JSON_parse': (...args) => safe.JSON_parseFn.call(safe.JSON, ...args),
        'JSON_stringify': (...args) => safe.JSON_stringifyFn.call(safe.JSON, ...args),
        'log': console.log.bind(console),
        // Properties
        logLevel: 0,
        // Methods
        makeLogPrefix(...args) {
            return this.sendToLogger && `[${args.join(' \u205D ')}]` || '';
        },
        uboLog(...args) {
            if ( this.sendToLogger === undefined ) { return; }
            if ( args === undefined || args[0] === '' ) { return; }
            return this.sendToLogger('info', ...args);
            
        },
        uboErr(...args) {
            if ( this.sendToLogger === undefined ) { return; }
            if ( args === undefined || args[0] === '' ) { return; }
            return this.sendToLogger('error', ...args);
        },
        escapeRegexChars(s) {
            return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        },
        initPattern(pattern, options = {}) {
            if ( pattern === '' ) {
                return { matchAll: true, expect: true };
            }
            const expect = (options.canNegate !== true || pattern.startsWith('!') === false);
            if ( expect === false ) {
                pattern = pattern.slice(1);
            }
            const match = /^\/(.+)\/([gimsu]*)$/.exec(pattern);
            if ( match !== null ) {
                return {
                    re: new this.RegExp(
                        match[1],
                        match[2] || options.flags
                    ),
                    expect,
                };
            }
            if ( options.flags !== undefined ) {
                return {
                    re: new this.RegExp(this.escapeRegexChars(pattern),
                        options.flags
                    ),
                    expect,
                };
            }
            return { pattern, expect };
        },
        testPattern(details, haystack) {
            if ( details.matchAll ) { return true; }
            if ( details.re ) {
                return this.RegExp_test.call(details.re, haystack) === details.expect;
            }
            return haystack.includes(details.pattern) === details.expect;
        },
        patternToRegex(pattern, flags = undefined, verbatim = false) {
            if ( pattern === '' ) { return /^/; }
            const match = /^\/(.+)\/([gimsu]*)$/.exec(pattern);
            if ( match === null ) {
                const reStr = this.escapeRegexChars(pattern);
                return new RegExp(verbatim ? `^${reStr}$` : reStr, flags);
            }
            try {
                return new RegExp(match[1], match[2] || undefined);
            }
            catch {
            }
            return /^/;
        },
        getExtraArgs(args, offset = 0) {
            const entries = args.slice(offset).reduce((out, v, i, a) => {
                if ( (i & 1) === 0 ) {
                    const rawValue = a[i+1];
                    const value = /^\d+$/.test(rawValue)
                        ? parseInt(rawValue, 10)
                        : rawValue;
                    out.push([ a[i], value ]);
                }
                return out;
            }, []);
            return this.Object_fromEntries(entries);
        },
        onIdle(fn, options) {
            if ( self.requestIdleCallback ) {
                return self.requestIdleCallback(fn, options);
            }
            return self.requestAnimationFrame(fn);
        },
        offIdle(id) {
            if ( self.requestIdleCallback ) {
                return self.cancelIdleCallback(id);
            }
            return self.cancelAnimationFrame(id);
        }
    };
    scriptletGlobals.safeSelf = safe;
    if ( scriptletGlobals.bcSecret === undefined ) { return safe; }
    // This is executed only when the logger is opened
    safe.logLevel = scriptletGlobals.logLevel || 1;
    let lastLogType = '';
    let lastLogText = '';
    let lastLogTime = 0;
    safe.toLogText = (type, ...args) => {
        if ( args.length === 0 ) { return; }
        const text = `[${document.location.hostname || document.location.href}]${args.join(' ')}`;
        if ( text === lastLogText && type === lastLogType ) {
            if ( (Date.now() - lastLogTime) < 5000 ) { return; }
        }
        lastLogType = type;
        lastLogText = text;
        lastLogTime = Date.now();
        return text;
    };
    try {
        const bc = new self.BroadcastChannel(scriptletGlobals.bcSecret);
        let bcBuffer = [];
        safe.sendToLogger = (type, ...args) => {
            const text = safe.toLogText(type, ...args);
            if ( text === undefined ) { return; }
            if ( bcBuffer === undefined ) {
                return bc.postMessage({ what: 'messageToLogger', type, text });
            }
            bcBuffer.push({ type, text });
        };
        bc.onmessage = ev => {
            const msg = ev.data;
            switch ( msg ) {
            case 'iamready!':
                if ( bcBuffer === undefined ) { break; }
                bcBuffer.forEach(({ type, text }) =>
                    bc.postMessage({ what: 'messageToLogger', type, text })
                );
                bcBuffer = undefined;
                break;
            case 'setScriptletLogLevelToOne':
                safe.logLevel = 1;
                break;
            case 'setScriptletLogLevelToTwo':
                safe.logLevel = 2;
                break;
            }
        };
        bc.postMessage('areyouready?');
    } catch {
        safe.sendToLogger = (type, ...args) => {
            const text = safe.toLogText(type, ...args);
            if ( text === undefined ) { return; }
            safe.log(`uBO ${text}`);
        };
    }
    return safe;
}

/******************************************************************************/

const scriptletGlobals = {}; // eslint-disable-line
const argsList = [["script","window,\"fetch\""],["script","offsetParent"],["script","/\\.textContent|Function\\(decodedScript\\)/"],["script","/adblock/i"],["script","location.reload"],["script","/google_jobrunner|AdBlock|pubadx|embed\\.html/i"],["script","adBlockEnabled"],["script","\"Anzeige\""],["script","adserverDomain"],["script","Promise"],["script","/adbl/i"],["script","Reflect"],["script","document.write"],["script","self == top"],["script","exdynsrv"],["script","/delete window|adserverDomain|FingerprintJS/"],["script","delete window"],["script","adsbygoogle"],["script","FingerprintJS"],["script","/h=decodeURIComponent|popundersPerIP/"],["script","/adblock.php"],["script","/adb/i"],["script","/document\\.createElement|\\.banner-in/"],["script","admbenefits"],["script","ExoLoader"],["script","/?key.*open/","condition","key"],["script","adblock"],["script","homad"],["script","popUnderUrl"],["script","Adblock"],["script","WebAssembly"],["script","detectAdBlock"],["script","/ABDetected|navigator.brave|fetch/"],["script","/ai_|b2a/"],["script","deblocker"],["script","/DName|#iframe_id/"],["script","adblockDetector"],["script","/bypass.php"],["script","htmls"],["script","toast"],["script","AdbModel"],["script","/popup/i"],["script","antiAdBlockerHandler"],["script","/ad\\s?block|adsBlocked|document\\.write\\(unescape\\('|devtool/i"],["script","onerror"],["script","/checkAdBlocker|AdblockRegixFinder/"],["script","catch"],["script","/adb_detected|AdBlockCheck|;break;case \\$\\./i"],["script","window.open"],["script","/aclib|break;|zoneNativeSett/"],["script","/fetch|popupshow/"],["script","justDetectAdblock"],["script","/FingerprintJS|openPopup/"],["script","DisableDevtool"],["script","popUp"],["script","/adsbygoogle|detectAdBlock/"],["script","onDevToolOpen"],["script","firstp"],["script","ctrlKey"],["script","/\\);break;case|advert_|POPUNDER_URL|adblock/"],["script","DisplayAcceptableAdIfAdblocked"],["script","adslotFilledByCriteo"],["script","/==undefined.*body/"],["script","/popunder|isAdBlock|admvn.src/i"],["script","/h=decodeURIComponent|\"popundersPerIP\"/"],["script","popMagic"],["script","/popMagic|pop1stp/"],["script","/shown_at|WebAssembly/"],["script",";}}};break;case $."],["script","globalThis;break;case"],["script","{delete window["],["script","wpadmngr.com"],["script","\"adserverDomain\""],["script","sandbox"],["script","/decodeURIComponent\\(escape|fairAdblock/"],["script","/ai_|googletag|adb/"],["script","adsBlocked"],["script","ai_adb"],["script","\"v4ac1eiZr0\""],["script","admiral"],["script","'').split(',')[4]"],["script","/\"v4ac1eiZr0\"|\"\"\\)\\.split\\(\",\"\\)\\[4\\]|(\\.localStorage\\)|JSON\\.parse\\(\\w)\\.getItem\\(\"|[\"']_aQS0\\w+[\"']/"],["script","error-report.com"],["script","html-load.com"],["script","KCgpPT57bGV0IGU"],["script","Ad-Shield"],["script","adrecover.com"],["script","\"data-sdk\""],["script","createOverlay"],["script","/detectAdblock|WebAssembly|pop1stp|popMagic/i"],["script","_ADX_"],["script","div.offsetHeight"],["script","/adbl|RegExp/i"],["script","/WebAssembly|forceunder/"],["script","/isAdBlocked|popUnderUrl/"],["script","/adb|offsetWidth|eval/i"],["script","contextmenu"],["script","/adblock|var Data.*];/"],["script","var Data"],["script","replace"],["style","text-decoration"],["script","/break;case|FingerprintJS/"],["script","push"],["script","AdBlocker"],["script","clicky"],["script","XV"],["script","Popunder"],["script","charCodeAt"],["script","localStorage"],["script","popunder"],["script","adbl"],["script","googlesyndication"],["script","blockAdBlock"],["script","/downloadJSAtOnload|Object.prototype.toString.call/"],["script","numberPages"],["script","brave"],["script","AreLoaded"],["script","AdblockRegixFinder"],["script","/adScript|adsBlocked/"],["script","serve"],["script","?metric=transit.counter&key=fail_redirect&tags="],["script","/pushAdTag|link_click|getAds/"],["script","/\\', [0-9]{5}\\)\\]\\; \\}/"],["script","/\\\",\\\"clickp\\\"\\:\\\"[0-9]{1,2}\\\"/"],["script","/ConsoleBan|alert|AdBlocker/"],["style","body:not(.ownlist)"],["script","mdpDeblocker"],["script","alert","condition","adblock"],["script","/deblocker|chp_ad/"],["script","await fetch"],["script","AdBlock"],["script","/'.adsbygoogle'|text-danger|warning|Adblock|_0x/"],["script","insertAdjacentHTML"],["script","popUnder"],["script","adb"],["#text","/スポンサーリンク|Sponsored Link|广告/"],["#text","スポンサーリンク"],["#text","スポンサードリンク"],["#text","/\\[vkExUnit_ad area=(after|before)\\]/"],["#text","【広告】"],["#text","関連動画"],["#text","PR:"],["script","leave_recommend"],["#text","/Advertisement/"],["script","liedetector"],["script","end_click"],["script","getComputedStyle"],["script","closeAd"],["script","/adconfig/i"],["script","is_antiblock_refresh"],["script","/userAgent|adb|htmls/"],["script","myModal"],["script","open"],["script","app_checkext"],["script","ad blocker"],["script","clientHeight"],["script","Brave"],["script","await"],["script","axios"],["script","/charAt|XMLHttpRequest/"],["script","AdBlockEnabled"],["script","window.location.replace"],["script","egoTab"],["script","/$.*(css|oncontextmenu)/"],["script","/eval.*RegExp/"],["script","wwads"],["script","popundersPerIP"],["script","/ads?Block/i"],["script","chkADB"],["script","Symbol.iterator"],["script","ai_cookie"],["script","/innerHTML.*appendChild/"],["script","Exo"],["script","AaDetector"],["script","/window\\[\\'open\\'\\]/"],["script","Error"],["script","/document\\.head\\.appendChild|window\\.open/"],["script","pop1stp"],["script","Number"],["script","NEXT_REDIRECT"],["script","ad-block-activated"],["script","pop.doEvent"],["script","Ads"],["script","detect"],["script","fetch"],["script","/hasAdblock|detect/"],["script","document.createTextNode"],["script","adsSrc"],["script","/adblock|popunder|openedPop|WebAssembly|wpadmngr/"],["script","/popMagic|nativeads|navigator\\.brave|\\.abk_msg|\\.innerHTML|ad block|manipulation/"],["script","window.warn"],["script","adBlock"],["script","adBlockDetected"],["script","/fetch|adb/i"],["script","location"],["script","showAd"],["script","imgSrc"],["script","document.createElement(\"script\")"],["script","antiAdBlock"],["script","/fairAdblock|popMagic/"],["script","aclib.runPop"],["script","mega-enlace.com/ext.php?o="],["script","Popup"],["script","displayAdsV3"],["script","adblocker"],["script","break;case"],["h2","/creeperhost/i"],["script","/interceptClickEvent|onbeforeunload|popMagic|location\\.replace/"],["script","/adserverDomain|\\);break;case /"],["script","initializeInterstitial"],["script","popupBackground"],["script","/h=decodeURIComponent|popundersPerIP|adserverDomain/"],["script","m9-ad-modal"],["script","Anzeige"],["script","blocking"],["script","HTMLAllCollection"],["script","LieDetector"],["script","advads"],["script","document.cookie"],["script","/h=decodeURIComponent|popundersPerIP|window\\.open|\\.createElement/"],["script","/_0x|brave|onerror/"],["script","window.googletag.pubads"],["script","kmtAdsData"],["script","navigator.userAgent"],["script","checkAdBlock"],["script","detectedAdblock"],["script","setADBFlag"],["script","/h=decodeURIComponent|popundersPerIP|wpadmngr|popMagic/"],["script","/wpadmngr|adserverDomain/"],["script","/account_ad_blocker|tmaAB/"],["script","ads_block"],["script","/getComputedStyle|overlay/"],["script","/adserverDomain|delete window|FingerprintJS/"],["script","/Popunder|Banner/"],["script","return a.split"],["script","/popundersPerIP|adserverDomain|wpadmngr/"],["script","==\"]"],["script","ads-blocked"],["script","#adbd"],["script","AdBl"],["script","/adblock|Cuba|noadb|popundersPerIP/i"],["script","/adserverDomain|ai_cookie/"],["script","/adsBlocked|\"popundersPerIP\"/"],["script","ab.php"],["script","wpquads_adblocker_check"],["script","__adblocker"],["script","/alert|brave|blocker/i"],["script","/ai_|eval|Google/"],["script","/delete window|popundersPerIP|FingerprintJS|adserverDomain|globalThis;break;case|ai_adb|adContainer/"],["script","/eval|adb/i"],["script","catcher"],["script","/setADBFlag|cRAds|\\;break\\;case|adManager|const popup/"],["script","/isAdBlockActive|WebAssembly/"],["script","videoList"],["script","freestar"],["script","/admiral/i"],["script","self.loadPW"],["script","onload"],["script","/andbox|adBlock|data-zone|histats|contextmenu|ConsoleBan/"],["script","closePlayer"],["script","_0x"],["script","destroyContent"],["script","advanced_ads_check_adblocker"],["script","'hidden'"],["script","/dismissAdBlock|533092QTEErr/"],["script","debugger"],["script","decodeURIComponent"],["script","adblock_popup"],["script","MutationObserver"],["script","ad-gate"],["script","/join\\(\\'\\'\\)/"],["script","/join\\(\\\"\\\"\\)/"],["script","api.dataunlocker.com"],["script","/^Function\\(\\\"/"],["script","vglnk"],["script","/detect|FingerprintJS/"],["script","/RegExp\\(\\'/","condition","RegExp"],["script","sendFakeRequest"]];
const hostnamesMap = new Map([["www.youtube.com",0],["poophq.com",1],["veev.to",1],["cdn.gledaitv.*",2],["faqwiki.*",3],["snapwordz.com",3],["toolxox.com",3],["rl6mans.com",3],["im9.eu",3],["marinetraffic.live",3],["nontonx.com",4],["embed.wcostream.com",5],["pandadoc.com",6],["web.de",7],["skidrowreloaded.com",[8,19]],["1337x.*",[8,19]],["1stream.eu",8],["4kwebplay.xyz",8],["alldownplay.xyz",8],["anime4i.vip",8],["antennasports.ru",[8,68]],["boxingstream.me",8],["buffstreams.app",8],["claplivehdplay.ru",8],["cracksports.me",[8,18]],["cricstream.me",8],["cricstreams.re",[8,18]],["dartsstreams.com",8],["dl-protect.link",8],["eurekaddl.baby",8],["euro2024direct.ru",8],["ext.to",8],["extrem-down.*",8],["extreme-down.*",8],["eztv.*",8],["eztvx.to",8],["f1box.me",8],["filecrypt.cc",8],["flix-wave.*",8],["flixrave.me",8],["golfstreams.me",8],["hikaritv.xyz",8],["ianimes.one",8],["istreameast.app",8],["jointexploit.net",[8,19]],["kenitv.me",[8,18]],["lewblivehdplay.ru",[8,210]],["mediacast.click",8],["mixdrop.*",[8,19]],["mlbbite.net",8],["mlbstreams.ai",8],["motogpstream.me",8],["nbabox.me",8],["nflbite.com",8],["nflbox.me",8],["nhlbox.me",8],["ogladaj.in",8],["playcast.click",8],["qatarstreams.me",[8,18]],["qqwebplay.xyz",[8,210]],["reidoscanais.life",8],["rnbastreams.com",8],["rugbystreams.me",8],["sanet.*",8],["socceronline.me",8],["soccerworldcup.me",[8,18]],["sportshd.*",8],["sportzonline.si",8],["streamed.su",8],["sushiscan.net",8],["topstreams.info",8],["totalsportek.to",8],["tvableon.me",[8,18]],["vecloud.eu",8],["vibestreams.*",8],["vipstand.pm",8],["webcamrips.to",8],["worldsports.me",8],["x1337x.*",8],["zone-telechargement.*",8],["720pstream.*",[8,68]],["embedsports.me",[8,101]],["embedstream.me",[8,18,19,68,101]],["reliabletv.me",[8,101]],["topembed.pw",[8,70,210]],["crackstreamer.net",8],["vidsrc.*",[8,18,68]],["vidco.pro",[8,68]],["freestreams-live.*>>",8],["moviepilot.de",[9,60]],["userupload.*",10],["cinedesi.in",10],["intro-hd.net",10],["monacomatin.mc",10],["nodo313.net",10],["mhdtvsports.*",[10,34]],["hesgoal-tv.io",10],["hesgoal-vip.io",10],["earn.punjabworks.com",10],["mahajobwala.in",10],["solewe.com",10],["panel.play.hosting",10],["total-sportek.to",10],["hesgoal-vip.to",10],["shoot-yalla.me",10],["shoot-yalla-tv.live",10],["pahe.*",[11,19,70]],["soap2day.*",11],["yts.mx",12],["hqq.*",13],["waaw.*",13],["pixhost.*",14],["vipbox.*",15],["telerium.*",16],["apex2nova.com",16],["hoca5.com",16],["germancarforum.com",17],["cybercityhelp.in",17],["innateblogger.com",17],["omeuemprego.online",17],["negyzetmeterarak.hu",17],["viprow.*",[18,19,68]],["bluemediadownload.*",18],["bluemediafile.*",18],["bluemedialink.*",18],["bluemediastorage.*",18],["bluemediaurls.*",18],["urlbluemedia.*",18],["bowfile.com",18],["cloudvideo.tv",[18,68]],["cloudvideotv.*",[18,68]],["coloredmanga.com",18],["exeo.app",18],["hiphopa.net",[18,19]],["megaup.net",18],["olympicstreams.co",[18,68]],["tv247.us",[18,19]],["uploadhaven.com",18],["userscloud.com",[18,68]],["streamnoads.com",[18,19,68,93]],["neodrive.xyz",18],["mdfx9dc8n.net",19],["mdzsmutpcvykb.net",19],["mixdrop21.net",19],["mixdropjmk.pw",19],["mexa.sh",19],["123-movies.*",19],["123movieshd.*",19],["123movieshub.*",19],["123moviesme.*",19],["1337x.ninjaproxy1.com",19],["1bit.space",19],["1bitspace.com",19],["1stream.*",19],["1tamilmv.*",19],["2ddl.*",19],["2umovies.*",19],["3dporndude.com",19],["3hiidude.*",19],["4archive.org",19],["4chanarchives.com",19],["4horlover.com",19],["4stream.*",19],["560pmovie.com",19],["5movies.*",19],["7hitmovies.*",19],["85videos.com",19],["9xmovie.*",19],["aagmaal.*",[19,68]],["acefile.co",19],["actusports.eu",19],["adblockeronstape.*",[19,93]],["adblockeronstreamtape.*",19],["adblockplustape.*",[19,93]],["adblockstreamtape.*",[19,93]],["adblockstrtape.*",[19,93]],["adblockstrtech.*",[19,93]],["adblocktape.*",[19,93]],["adclickersbot.com",19],["adcorto.*",19],["adricami.com",19],["adslink.pw",[19,66]],["adultstvlive.com",19],["adz7short.space",19],["aeblender.com",19],["affordwonder.net",19],["ahdafnews.blogspot.com",19],["aiblog.tv",[19,71]],["ak47sports.com",19],["akuma.moe",19],["alexsports.*",[19,248]],["alexsportss.*",19],["alexsportz.*",19],["allplayer.tk",19],["amateurblog.tv",[19,71]],["androidadult.com",[19,237]],["anhsexjav.xyz",19],["anidl.org",19],["anime-loads.org",19],["animeblkom.net",19],["animefire.plus",19],["animelek.me",19],["animepahe.*",19],["animesanka.*",19],["animesorionvip.net",19],["animespire.net",19],["animestotais.xyz",19],["animeyt.es",19],["animixplay.*",19],["aniplay.*",19],["anroll.net",19],["antiadtape.*",[19,93]],["anymoviess.xyz",19],["aotonline.org",19],["asenshu.com",19],["asialiveaction.com",19],["asianclipdedhd.net",19],["asianclub.*",19],["ask4movie.*",19],["askim-bg.com",19],["assistirtvonlinebr.net",19],["asumsikedaishop.com",19],["atomixhq.*",[19,68]],["atomohd.*",19],["avcrempie.com",19],["avseesee.com",19],["gettapeads.com",[19,93]],["bajarjuegospcgratis.com",19],["balkanteka.net",19],["beastvid.tv",19],["beinmatch.*",[19,25]],["belowporn.com",19],["bestgirlsexy.com",19],["bestnhl.com",19],["bestporncomix.com",19],["bhaai.*",19],["bigwarp.*",19],["bikinbayi.com",19],["bikinitryon.net",19],["birdurls.com",19],["bitsearch.to",19],["blackcockadventure.com",19],["blackcockchurch.org",19],["blackporncrazy.com",19],["blizzboygames.net",19],["blizzpaste.com",19],["blkom.com",19],["blog-peliculas.com",19],["blogtrabalhista.com",19],["blurayufr.*",19],["bobsvagene.club",19],["bokep.im",19],["bokep.top",19],["bokepnya.com",19],["bollyflix.cards",19],["boyfuck.me",19],["brilian-news.id",19],["brupload.net",19],["buffstreams.*",19],["buzter.xyz",19],["caitlin.top",19],["camchickscaps.com",19],["camgirls.casa",19],["canalesportivo.*",19],["cashurl.in",19],["ccurl.net",[19,68]],["cdn1.site",[19,51]],["charexempire.com",19],["cizgivedizi.com",19],["clickndownload.*",19],["clicknupload.*",[19,70]],["clik.pw",19],["coin-free.com",[19,38]],["coins100s.fun",19],["comohoy.com",19],["coolcast2.com",19],["cordneutral.net",19],["countylocalnews.com",19],["cpmlink.net",19],["crackstreamshd.click",19],["crespomods.com",19],["crisanimex.com",19],["crunchyscan.fr",19],["cuevana3.fan",19],["cuevana3hd.com",19],["cumception.com",19],["cutpaid.com",19],["daddylive.*",[19,68,208]],["daddylivehd.*",[19,68]],["daddylivestream.com",[19,208]],["dailyuploads.net",19],["darkmahou.org",19],["datawav.club",19],["daughtertraining.com",19],["ddrmovies.*",19],["deepgoretube.site",19],["deltabit.co",19],["deporte-libre.top",19],["depvailon.com",19],["derleta.com",19],["desiremovies.*",19],["desivdo.com",19],["desixx.net",19],["detikkebumen.com",19],["deutschepornos.me",19],["devlib.*",19],["diasoft.xyz",19],["dipelis.junctionjive.co.uk",19],["directupload.net",19],["divxtotal.*",19],["divxtotal1.*",19],["dixva.com",19],["dlhd.*",[19,208]],["doctormalay.com",19],["dofusports.xyz",19],["doods.cam",19],["doodskin.lat",19],["downloadrips.com",19],["downvod.com",19],["dphunters.mom",19],["dragontranslation.com",19],["dvdfullestrenos.com",19],["dvdplay.*",[19,68]],["dx-tv.com",[19,34]],["ebookbb.com",19],["ebookhunter.net",19],["egyanime.com",19],["egygost.com",19],["ekasiwap.com",19],["electro-torrent.pl",19],["elixx.*",19],["elrefugiodelpirata.com",19],["enjoy4k.*",19],["eplayer.click",19],["erovoice.us",19],["eroxxx.us",19],["estrenosdoramas.net",19],["estrenosflix.*",19],["estrenosflux.*",19],["estrenosgo.*",19],["everia.club",19],["everythinginherenet.blogspot.com",19],["extratorrent.st",19],["extremotvplay.com",19],["f1stream.*",19],["fapinporn.com",19],["fapptime.com",19],["fastreams.live",19],["faucethero.com",19],["favoyeurtube.net",19],["fbstream.*",19],["fc2db.com",19],["femdom-joi.com",[19,71]],["fenixsite.net",19],["file4go.*",19],["filegram.to",[19,66,71]],["fileone.tv",19],["film1k.com",19],["filmeonline2023.net",19],["filmesonlinex.org",19],["filmesonlinexhd.biz",19],["filmisub.cc",19],["filmovitica.com",19],["filmymaza.blogspot.com",19],["filmyzilla.*",[19,68]],["filthy.family",19],["findav.*",19],["findporn.*",19],["flickzap.com",19],["flixmaza.*",19],["flizmovies.*",19],["flostreams.xyz",19],["flyfaucet.com",19],["footyhunter.lol",19],["forex-trnd.com",19],["forumchat.club",19],["forumlovers.club",19],["freeomovie.co.in",19],["freeomovie.to",19],["freeporncomic.net",19],["freepornhdonlinegay.com",19],["freeproxy.io",19],["freeshot.live",19],["freetvsports.*",19],["freeuse.me",19],["freeusexporn.com",19],["fsharetv.cc",19],["fsicomics.com",19],["fullymaza.*",19],["g-porno.com",19],["g3g.*",19],["galinhasamurai.com",19],["gamepcfull.com",19],["gamesmountain.com",19],["gamesrepacks.com",19],["gamingguru.fr",19],["gamovideo.com",19],["garota.cf",19],["gaydelicious.com",19],["gayfor.us",19],["gaypornhdfree.com",19],["gaypornhot.com",19],["gaypornmasters.com",19],["gaysex69.net",19],["gemstreams.com",19],["get-to.link",19],["girlscanner.org",19],["giurgiuveanul.ro",19],["gledajcrtace.xyz",19],["gocast2.com",19],["gomo.to",19],["gostosa.cf",19],["gotxx.*",19],["grantorrent.*",19],["gratispaste.com",19],["gravureblog.tv",[19,71]],["gupload.xyz",19],["haho.moe",19],["hayhd.net",19],["hdmoviesfair.*",[19,68]],["hdmoviesflix.*",19],["hdpornflix.com",19],["hdsaprevodom.com",19],["hdstreamss.club",19],["hentaiporno.xxx",19],["hentais.tube",19],["hentaistream.co",19],["hentaitk.net",19],["hentaitube.online",19],["hentaiworld.tv",19],["hesgoal.tv",19],["hexupload.net",19],["hhkungfu.tv",19],["highlanderhelp.com",19],["hiidudemoviez.*",19],["hindimovies.to",[19,68]],["hindimoviestv.com",19],["hiperdex.com",19],["hispasexy.org",19],["hitomi.la",19],["hitprn.com",19],["hivflix.*",19],["hoca4u.com",19],["hollymoviehd.cc",19],["hoodsite.com",19],["hopepaste.download",19],["hornylips.com",19],["hotgranny.live",19],["hotmama.live",19],["hqcelebcorner.net",19],["huren.best",19],["hwnaturkya.com",[19,68]],["hxfile.co",[19,68]],["igfap.com",19],["iklandb.com",19],["illink.net",19],["imgsen.*",19],["imgsex.xyz",19],["imgsto.*",19],["imgtraffic.com",19],["imx.to",19],["incest.*",19],["incestflix.*",19],["influencersgonewild.org",19],["infosgj.free.fr",19],["investnewsbrazil.com",19],["itdmusics.com",19],["itopmusic.*",19],["itsuseful.site",19],["itunesfre.com",19],["iwatchfriendsonline.net",[19,144]],["japangaysex.com",19],["jav-noni.cc",19],["javboys.tv",19],["javcl.com",19],["jav-coco.com",19],["javhay.net",19],["javhun.com",19],["javleak.com",19],["javmost.*",19],["javporn.best",19],["javsek.net",19],["javsex.to",19],["javtiful.com",[19,21]],["jimdofree.com",19],["jiofiles.org",19],["jorpetz.com",19],["jp-films.com",19],["jpop80ss3.blogspot.com",19],["jpopsingles.eu",[19,187]],["jrants.com",[19,77]],["justfullporn.net",19],["kantotflix.net",19],["kaplog.com",19],["kasiporn.com",19],["keeplinks.*",19],["keepvid.*",19],["keralahd.*",19],["khatrimazaful.*",19],["khatrimazafull.*",[19,71]],["kimochi.info",19],["kimochi.tv",19],["kinemania.tv",19],["kissasian.*",19],["kolnovel.site",19],["koltry.life",19],["konstantinova.net",19],["koora-online.live",19],["kunmanga.com",[19,68]],["kwithsub.com",19],["lat69.me",19],["latinblog.tv",[19,71]],["latinomegahd.net",19],["leechall.*",19],["leechpremium.link",19],["legendas.dev",19],["legendei.net",19],["lighterlegend.com",19],["linclik.com",19],["linkebr.com",19],["linkrex.net",19],["linkshorts.*",19],["lulu.st",19],["lulustream.com",[19,70]],["lulustream.live",19],["luluvdo.com",19],["luluvdoo.com",19],["mangaweb.xyz",19],["mangovideo.*",19],["masahub.com",19],["masahub.net",19],["masaporn.*",19],["maturegrannyfuck.com",19],["mdy48tn97.com",19],["mediapemersatubangsa.com",19],["mega-mkv.com",19],["megapastes.com",19],["megapornpics.com",19],["messitv.net",19],["meusanimes.net",19],["milfmoza.com",19],["milfnut.*",19],["milfzr.com",19],["millionscast.com",19],["mimaletamusical.blogspot.com",19],["miniurl.*",19],["mirrorace.*",19],["mitly.us",19],["mixdroop.*",19],["mixixxx000000.cyou",19],["mixixxx696969.cyou",19],["miztv.top",19],["mkv-pastes.com",19],["mkvcage.*",19],["mlbstream.*",19],["mlsbd.*",19],["mmsbee.*",19],["monaskuliner.ac.id",19],["moredesi.com",19],["motogpstream.*",19],["moutogami.com",19],["movgotv.net",19],["movi.pk",19],["movieplex.*",19],["movierulzlink.*",19],["movies123.*",[19,71]],["moviesflix.*",19],["moviesmeta.*",19],["moviesmod.com.pl",19],["moviessources.*",19],["moviesverse.*",19],["movieswbb.com",19],["moviewatch.com.pk",19],["moviezwaphd.*",19],["mp4upload.com",19],["mrskin.live",19],["mrunblock.*",19],["multicanaistv.com",19],["mundowuxia.com",19],["multicanais.*",19],["myeasymusic.ir",19],["myonvideo.com",19],["myyouporn.com",19],["mzansifun.com",19],["naughtypiss.com",19],["nbastream.*",19],["nekopoi.*",[19,71]],["netfapx.com",19],["netfuck.net",19],["new-fs.eu",19],["newmovierulz.*",19],["newtorrentgame.com",19],["neymartv.net",19],["nflstream.*",19],["nflstreams.me",19],["nhlstream.*",19],["nicekkk.com",19],["nicesss.com",19],["nlegs.com",19],["noblocktape.*",[19,93]],["nocensor.*",19],["noni-jav.com",19],["notformembersonly.com",19],["novamovie.net",19],["novelpdf.xyz",19],["novelssites.com",[19,68]],["novelup.top",19],["nsfwr34.com",19],["nu6i-bg-net.com",19],["nudebabesin3d.com",19],["nzbstars.com",19],["o2tvseries.com",19],["ohjav.com",19],["ojearnovelas.com",19],["okanime.xyz",19],["olweb.tv",19],["olympusbiblioteca.site",19],["on9.stream",19],["onepiece-mangaonline.com",19],["onifile.com",19],["onionstream.live",19],["onlinesaprevodom.net",19],["onlyfams.*",19],["onlyfullporn.video",19],["onplustv.live",19],["originporn.com",19],["ouo.*",19],["ovagames.com",19],["pastemytxt.com",19],["payskip.org",19],["pctfenix.*",[19,68]],["pctnew.*",[19,68]],["peeplink.in",19],["peliculas24.*",19],["peliculasmx.net",19],["pelisflix20.*",19],["pelisplus.*",19],["pelisxporno.net",19],["pencarian.link",19],["pendidikandasar.net",19],["pervertgirlsvideos.com",19],["pervyvideos.com",19],["phim12h.com",19],["picdollar.com",19],["picsxxxporn.com",19],["pinayscandalz.com",19],["pinkueiga.net",19],["piratebay.*",19],["piratefast.xyz",19],["piratehaven.xyz",19],["pirateiro.com",19],["playtube.co.za",19],["plugintorrent.com",19],["plyjam.*",19],["plylive.*",19],["plyvdo.*",19],["pmvzone.com",19],["porndish.com",19],["pornez.net",19],["pornfetishbdsm.com",19],["pornfits.com",19],["pornhd720p.com",19],["pornhoarder.*",[19,228]],["pornobr.club",19],["pornobr.ninja",19],["pornodominicano.net",19],["pornofaps.com",19],["pornoflux.com",19],["pornotorrent.com.br",19],["pornredit.com",19],["pornstarsyfamosas.es",19],["pornstreams.co",19],["porntn.com",19],["pornxbit.com",19],["pornxday.com",19],["portaldasnovinhas.shop",19],["portugues-fcr.blogspot.com",19],["poseyoung.com",19],["pover.org",19],["prbay.*",19],["projectfreetv.*",19],["projeihale.com",19],["proxybit.*",19],["proxyninja.org",19],["psarips.*",19],["pubfilmz.com",19],["publicsexamateurs.com",19],["punanihub.com",19],["pxxbay.com",19],["qiqitvx84.shop",19],["r18.best",19],["racaty.*",19],["ragnaru.net",19],["rapbeh.net",19],["rapelust.com",19],["rapload.org",19],["read-onepiece.net",19],["readhunters.xyz",19],["remaxhd.*",19],["reshare.pm",19],["retro-fucking.com",19],["retrotv.org",19],["rintor.*",19],["rnbxclusive.*",19],["rnbxclusive0.*",19],["rnbxclusive1.*",19],["robaldowns.com",19],["rockdilla.com",19],["rojadirecta.*",19],["rojadirectaenvivo.*",19],["rojitadirecta.blogspot.com",19],["romancetv.site",19],["rsoccerlink.site",19],["rugbystreams.*",19],["rule34.club",19],["rule34hentai.net",19],["rumahbokep-id.com",19],["sadisflix.*",19],["safego.cc",19],["safetxt.*",19],["sakurafile.com",19],["samax63.lol",19],["savefiles.com",[19,66]],["scat.gold",19],["scatfap.com",19],["scatkings.com",19],["sexdicted.com",19],["sexgay18.com",19],["sexiezpix.com",19],["sextubebbw.com",19],["sgpics.net",19],["shadowrangers.*",19],["shahed-4u.day",19],["shahee4u.cam",19],["shahi4u.*",19],["shahid4u1.*",19],["shahid4uu.*",19],["shahiid-anime.net",19],["shavetape.*",19],["shemale6.com",19],["shemalegape.net",[19,65]],["shid4u.*",19],["shinden.pl",19],["short.es",19],["shortearn.*",19],["shorten.*",19],["shorttey.*",19],["shortzzy.*",19],["showmanga.blog.fc2.com",19],["shrt10.com",19],["sideplusleaks.net",19],["silverblog.tv",[19,71]],["silverpic.com",19],["sinhalasub.life",19],["sinsitio.site",19],["sinvida.me",19],["skidrowcpy.com",19],["skymovieshd.*",19],["slut.mom",19],["smallencode.me",19],["smoner.com",19],["smplace.com",19],["soccerinhd.com",[19,68]],["socceron.name",19],["socceronline.*",[19,68]],["socialblog.tv",[19,71]],["softairbay.com",19],["softarchive.*",19],["sokobj.com",19],["songsio.com",19],["souexatasmais.com",19],["speedporn.net",[19,71]],["sportbar.live",19],["sports-stream.*",19],["sportstream1.cfd",19],["sporttuna.*",19],["sporttunatv.*",19],["srt.am",19],["srts.me",19],["sshhaa.*",19],["stapadblockuser.*",[19,93]],["stape.*",[19,93]],["stapewithadblock.*",19],["starblog.tv",[19,71]],["starmusiq.*",19],["stbemuiptv.com",19],["stockingfetishvideo.com",19],["strcloud.*",[19,93]],["stream.crichd.vip",19],["stream.lc",19],["stream25.xyz",19],["streamadblocker.*",[19,68,93]],["streamadblockplus.*",[19,93]],["streambee.to",19],["streambucket.net",19],["streamcdn.*",19],["streamcenter.pro",19],["streamers.watch",19],["streamgo.to",19],["streamhub.*",[19,68]],["streamingclic.com",19],["streamkiste.tv",19],["streamoupload.xyz",19],["streamservicehd.click",19],["streamsport.*",19],["streamta.*",[19,93]],["streamtape.*",[19,71,93]],["streamtapeadblockuser.*",[19,93]],["streamvid.net",[19,26]],["strikeout.*",[19,70]],["strtape.*",[19,93]],["strtapeadblock.*",[19,93]],["strtapeadblocker.*",[19,93]],["strtapewithadblock.*",19],["strtpe.*",[19,93]],["subtitleporn.com",19],["subtitles.cam",19],["suicidepics.com",19],["supertelevisionhd.com",19],["supexfeeds.com",19],["swatchseries.*",19],["swiftload.io",19],["swipebreed.net",19],["swzz.xyz",19],["sxnaar.com",19],["tabooflix.*",19],["taboosex.club",19],["tapeantiads.com",[19,93]],["tapeblocker.com",[19,93]],["tapenoads.com",[19,93]],["tapepops.com",[19,71,93]],["tapewithadblock.org",[19,93,276]],["teamos.xyz",19],["telegramgroups.xyz",19],["telenovelasweb.com",19],["tempodeconhecer.blogs.sapo.pt",19],["tennisstreams.*",19],["tensei-shitara-slime-datta-ken.com",19],["tfp.is",19],["tgo-tv.co",[19,68]],["thaihotmodels.com",19],["theblueclit.com",19],["thebussybandit.com",19],["thedaddy.*",[19,208]],["thelastdisaster.vip",19],["themoviesflix.*",19],["thepiratebay.*",19],["thepiratebay0.org",19],["thepiratebay10.info",19],["thesexcloud.com",19],["thothub.today",19],["tightsexteens.com",19],["tlnovelas.net",19],["tmearn.*",19],["tojav.net",19],["tokusatsuindo.com",19],["tokyocafe.org",19],["toonanime.*",19],["top16.net",19],["topdrama.net",19],["topvideosgay.com",19],["torlock.*",19],["tormalayalam.*",19],["torrage.info",19],["torrents.vip",19],["torrentz2eu.*",19],["torrsexvid.com",19],["tpb-proxy.xyz",19],["trannyteca.com",19],["trendytalker.com",19],["tuktukcinma.com",19],["tumanga.net",19],["turbogvideos.com",19],["turboimagehost.com",19],["turbovid.me",19],["turkishseriestv.org",19],["turksub24.net",19],["tutele.sx",19],["tutelehd.*",19],["tvglobe.me",19],["tvpclive.com",19],["tvply.*",19],["tvs-widget.com",19],["tvseries.video",19],["u4m.*",19],["ucptt.com",19],["ufaucet.online",19],["ufcfight.online",19],["ufcstream.*",19],["ultrahorny.com",19],["ultraten.net",19],["unblocknow.*",19],["unblockweb.me",19],["underhentai.net",19],["uniqueten.net",19],["uns.bio",19],["upbaam.com",19],["uploadbuzz.*",19],["upstream.to",19],["upzur.com",19],["usagoals.*",19],["ustream.to",19],["valhallas.click",19],["valeriabelen.com",19],["verdragonball.online",19],["vexmoviex.*",19],["vfxmed.com",19],["vidclouds.*",19],["video.az",19],["videostreaming.rocks",19],["videowood.tv",19],["vidlox.*",19],["vidorg.net",19],["vidtapes.com",19],["vidz7.com",19],["vikistream.com",19],["vinovo.to",19],["vipboxtv.*",[19,68]],["vipleague.*",[19,232]],["virpe.cc",19],["visifilmai.org",19],["viveseries.com",19],["vladrustov.sx",19],["volokit2.com",[19,68,208]],["vstorrent.org",19],["w4hd.com",19],["watch-series.*",19],["watchbrooklynnine-nine.com",19],["watchelementaryonline.com",19],["watchf1full.com",19],["watchfamilyguyonline.com",19],["watchkobestreams.info",19],["watchlostonline.net",19],["watchmmafull.com",19],["watchmodernfamilyonline.com",19],["watchmonkonline.com",19],["watchrulesofengagementonline.com",19],["watchseries.*",19],["webcamrips.com",19],["wincest.xyz",19],["wolverdon.fun",19],["wordcounter.icu",19],["worldmovies.store",19],["worldstreams.click",19],["wpdeployit.com",19],["wqstreams.tk",19],["wwwsct.com",19],["x18hub.com",19],["xanimeporn.com",19],["xblog.tv",[19,71]],["xclusivejams.*",19],["xmoviesforyou.*",19],["xn--verseriesespaollatino-obc.online",19],["xpornium.net",19],["xsober.com",19],["xvip.lat",19],["xxgasm.com",19],["xxvideoss.org",19],["xxx18.uno",19],["xxxdominicana.com",19],["xxxfree.watch",19],["xxxmax.net",19],["xxxwebdlxxx.top",19],["xxxxvideo.uno",19],["yabai.si",19],["yeshd.net",19],["youdbox.*",19],["youjax.com",19],["yourdailypornvideos.ws",19],["yourupload.com",19],["youswear.com",19],["ytmp3eu.*",19],["yts-subs.*",19],["yts.*",19],["ytstv.me",19],["yumeost.net",19],["zerion.cc",19],["zerocoin.top",19],["zitss.xyz",19],["zooqle.*",19],["zpaste.net",19],["fastreams.com",19],["streamsoccer.site",19],["tntsports.store",19],["wowstreams.co",19],["dutchycorp.*",20],["faucet.ovh",20],["mmacore.tv",21],["nxbrew.net",21],["brawlify.com",21],["oko.sh",22],["variety.com",[23,81]],["gameskinny.com",23],["deadline.com",[23,81]],["mlive.com",[23,81]],["sexo5k.com",24],["truyen-hentai.com",24],["theshedend.com",26],["cybermania.ws",26],["zeroupload.com",26],["securenetsystems.net",26],["miniwebtool.com",26],["bchtechnologies.com",26],["eracast.cc",26],["flatai.org",26],["leeapk.com",26],["spiegel.de",27],["jacquieetmichel.net",28],["hausbau-forum.de",29],["althub.club",29],["kiemlua.com",29],["doujindesu.*",30],["atlasstudiousa.com",30],["51bonusrummy.in",[30,71]],["tackledsoul.com",31],["adrino1.bonloan.xyz",31],["vi-music.app",31],["instanders.app",31],["rokni.xyz",31],["keedabankingnews.com",31],["sampledrive.org",[31,74]],["windroid777.com",31],["z80ne.com",31],["tea-coffee.net",32],["spatsify.com",32],["newedutopics.com",32],["getviralreach.in",32],["edukaroo.com",32],["funkeypagali.com",32],["careersides.com",32],["nayisahara.com",32],["wikifilmia.com",32],["infinityskull.com",32],["viewmyknowledge.com",32],["iisfvirtual.in",32],["starxinvestor.com",32],["jkssbalerts.com",32],["imagereviser.com",33],["veganab.co",34],["camdigest.com",34],["learnmany.in",34],["amanguides.com",[34,40]],["highkeyfinance.com",[34,40]],["appkamods.com",34],["techacode.com",34],["djqunjab.in",34],["downfile.site",34],["expertvn.com",34],["trangchu.news",34],["shemaleraw.com",34],["thecustomrom.com",34],["wemove-charity.org",34],["nulleb.com",34],["snlookup.com",34],["bingotingo.com",34],["ghior.com",34],["3dmili.com",34],["karanpc.com",34],["plc247.com",34],["apkdelisi.net",34],["freepasses.org",34],["poplinks.*",[34,44]],["tomarnarede.pt",34],["basketballbuzz.ca",34],["dribbblegraphics.com",34],["kemiox.com",34],["teksnologi.com",34],["bharathwick.com",34],["descargaspcpro.net",34],["rt3dmodels.com",34],["plc4me.com",34],["blisseyhusbands.com",34],["mhdsports.*",34],["mhdsportstv.*",34],["mhdtvworld.*",34],["mhdtvmax.*",34],["mhdstream.*",34],["madaradex.org",34],["trigonevo.com",34],["franceprefecture.fr",34],["jazbaat.in",34],["aipebel.com",34],["audiotools.blog",34],["embdproxy.xyz",34],["fc-lc.*",35],["jobzhub.store",36],["fitdynamos.com",36],["labgame.io",36],["kenzo-flowertag.com",37],["mdn.lol",37],["btcbitco.in",38],["btcsatoshi.net",38],["cempakajaya.com",38],["crypto4yu.com",38],["manofadan.com",38],["readbitcoin.org",38],["wiour.com",38],["tremamnon.com",38],["bitsmagic.fun",38],["ourcoincash.xyz",38],["aylink.co",39],["sugarona.com",40],["nishankhatri.xyz",40],["cety.app",41],["exe-urls.com",41],["exego.app",41],["cutlink.net",41],["cutyurls.com",41],["cutty.app",41],["cutnet.net",41],["jixo.online",41],["tinys.click",42],["loan.creditsgoal.com",42],["rupyaworld.com",42],["vahantoday.com",42],["techawaaz.in",42],["loan.bgmi32bitapk.in",42],["formyanime.com",42],["gsm-solution.com",42],["h-donghua.com",42],["hindisubbedacademy.com",42],["hm4tech.info",42],["mydverse.*",42],["panelprograms.blogspot.com",42],["ripexbooster.xyz",42],["serial4.com",42],["tutorgaming.com",42],["unblockedgamesgplus.gitlab.io",42],["everydaytechvams.com",42],["dipsnp.com",42],["cccam4sat.com",42],["diendancauduong.com",42],["stitichsports.com",42],["aiimgvlog.fun",43],["appsbull.com",44],["diudemy.com",44],["maqal360.com",44],["androjungle.com",44],["bookszone.in",44],["shortix.co",44],["makefreecallsonline.com",44],["msonglyrics.com",44],["app-sorteos.com",44],["bokugents.com",44],["client.pylexnodes.net",44],["btvplus.bg",44],["listar-mc.net",44],["coingraph.us",45],["impact24.us",45],["iconicblogger.com",46],["auto-crypto.click",46],["tpi.li",47],["shrinkme.*",48],["shrinke.*",48],["mrproblogger.com",48],["themezon.net",48],["smutty.com",48],["e-sushi.fr",48],["gayforfans.com",48],["freeadultcomix.com",48],["down.dataaps.com",48],["filmweb.pl",[48,182]],["livecamrips.*",48],["safetxt.net",48],["filespayouts.com",48],["atglinks.com",49],["kbconlinegame.com",50],["hamrojaagir.com",50],["odijob.com",50],["stfly.biz",51],["airevue.net",51],["atravan.net",51],["simana.online",52],["fooak.com",52],["joktop.com",52],["evernia.site",52],["falpus.com",52],["rfiql.com",53],["gujjukhabar.in",53],["smartfeecalculator.com",53],["djxmaza.in",53],["thecubexguide.com",53],["jytechs.in",53],["financacerta.com",54],["encurtads.net",54],["mastkhabre.com",55],["weshare.is",56],["vplink.in",57],["3dsfree.org",58],["up4load.com",59],["alpin.de",60],["boersennews.de",60],["chefkoch.de",60],["chip.de",60],["clever-tanken.de",60],["desired.de",60],["donnerwetter.de",60],["fanfiktion.de",60],["focus.de",60],["formel1.de",60],["frustfrei-lernen.de",60],["gewinnspiele.tv",60],["giga.de",60],["gut-erklaert.de",60],["kino.de",60],["messen.de",60],["nickles.de",60],["nordbayern.de",60],["spielfilm.de",60],["teltarif.de",[60,61]],["unsere-helden.com",60],["weltfussball.at",60],["watson.de",60],["mactechnews.de",60],["sport1.de",60],["welt.de",60],["sport.de",60],["allthingsvegas.com",62],["100percentfedup.com",62],["beforeitsnews.com",62],["concomber.com",62],["conservativefiringline.com",62],["dailylol.com",62],["funnyand.com",62],["letocard.fr",62],["mamieastuce.com",62],["meilleurpronostic.fr",62],["patriotnationpress.com",62],["toptenz.net",62],["vitamiiin.com",62],["writerscafe.org",62],["populist.press",62],["dailytruthreport.com",62],["livinggospeldaily.com",62],["first-names-meanings.com",62],["welovetrump.com",62],["thehayride.com",62],["thelibertydaily.com",62],["thepoke.co.uk",62],["thepolitistick.com",62],["theblacksphere.net",62],["shark-tank.com",62],["naturalblaze.com",62],["greatamericanrepublic.com",62],["dailysurge.com",62],["truthlion.com",62],["flagandcross.com",62],["westword.com",62],["republicbrief.com",62],["freedomfirstnetwork.com",62],["phoenixnewtimes.com",62],["designbump.com",62],["clashdaily.com",62],["madworldnews.com",62],["reviveusa.com",62],["sonsoflibertymedia.com",62],["thedesigninspiration.com",62],["videogamesblogger.com",62],["protrumpnews.com",62],["thepalmierireport.com",62],["kresy.pl",62],["thepatriotjournal.com",62],["thegatewaypundit.com",62],["wltreport.com",62],["miaminewtimes.com",62],["politicalsignal.com",62],["rightwingnews.com",62],["bigleaguepolitics.com",62],["comicallyincorrect.com",62],["upornia.com",63],["pillowcase.su",64],["akaihentai.com",65],["cine-calidad.*",65],["fastpic.org",[65,71]],["forums.socialmediagirls.com",[65,71]],["javtsunami.com",65],["manwa.me",65],["monoschino2.com",65],["saradahentai.com",65],["sxyprn.*",65],["tabooporn.tv",65],["veryfreeporn.com",65],["x-video.tube",65],["pornoenspanish.es",65],["theporngod.com",65],["tabootube.to",65],["bebasbokep.online",66],["besthdgayporn.com",66],["dimensionalseduction.com",66],["drivenime.com",66],["erothots1.com",66],["javup.org",66],["kaliscan.*",66],["madouqu.com",66],["shemaleup.net",66],["transflix.net",66],["worthcrete.com",66],["x-x-x.video",[66,266]],["hentaihere.com",67],["player.smashy.stream",67],["player.smashystream.com",67],["11xmovies.*",[68,70]],["123movies.*",68],["123moviesla.*",68],["123movieweb.*",68],["2embed.*",68],["3kmovies.*",68],["720pflix.*",68],["7starhd.*",68],["9xflix.*",68],["9xmovies.*",68],["adsh.cc",68],["adshort.*",68],["afilmyhouse.blogspot.com",68],["ak.sv",68],["aliezstream.pro",[68,166]],["allmovieshub.*",68],["animesultra.net",68],["api.webs.moe",68],["apkmody.io",68],["asianplay.*",68],["atishmkv.*",68],["backfirstwo.site",68],["bflix.*",68],["crazyblog.in",68],["cricstream.*",68],["crictime.*",68],["cuervotv.me",68],["defienietlynotme.com",68],["divicast.com",68],["dood.*",[68,188]],["dooood.*",[68,188]],["egybest.*",68],["embedme.*",68],["embedpk.net",68],["esportivos.site",68],["extramovies.*",68],["faselhd.*",68],["faselhds.*",68],["faselhdwatch.*",68],["filemoon.*",68],["filemooon.*",68],["filmeserialeonline.org",68],["filmy.*",68],["filmyhit.*",68],["filmywap.*",68],["finfang.*",68],["flexyhit.com",68],["flixhq.*",68],["fmembed.cc",68],["fmoonembed.*",68],["fmovies.*",68],["focus4ca.com",68],["footybite.to",68],["foreverwallpapers.com",68],["french-streams.cc",68],["gdplayer.*",68],["gdrivelatinohd.net",68],["globalstreams.xyz",68],["gocast.pro",68],["godzcast.com",68],["goku.sx",68],["gomovies.*",68],["gowatchseries.*",68],["hdfungamezz.*",68],["hdmovies23.*",68],["hdtoday.to",68],["hellnaw.*",68],["hianime.to",68],["hinatasoul.com",68],["hindilinks4u.*",68],["hurawatch.*",68],["igg-games.com",68],["infinityscans.net",68],["jalshamoviezhd.*",68],["kaido.to",68],["kerapoxy.*",68],["linkshub.*",68],["livecricket.*",68],["livestreames.us",68],["locatedinfain.com",68],["mangareader.to",68],["maxstream.*",68],["mhdsport.*",68],["mkvcinemas.*",68],["moonembed.*",68],["moviekids.tv",68],["movies2watch.*",68],["moviesda9.co",68],["moviespapa.*",68],["mp4moviez.*",68],["mydownloadtube.*",68],["myflixertv.to",68],["myflixerz.to",68],["mylivestream.pro",[68,166]],["nowmetv.net",68],["nowsportstv.com",68],["nuroflix.*",68],["nxbrew.com",68],["o2tvseries.*",68],["o2tvseriesz.*",68],["oii.io",68],["paidshitforfree.com",68],["pepperlive.info",68],["pirlotv.*",68],["pkspeed.net",68],["playertv.net",68],["poscitech.*",68],["primewire.*",68],["redecanais.*",68],["rgeyyddl.*",68],["ronaldo7.pro",68],["roystream.com",68],["rssing.com",68],["s.to",68],["serienstream.*",68],["sflix.*",68],["shahed4u.*",68],["shaheed4u.*",68],["share.filesh.site",68],["sharkfish.xyz",68],["skidrowcodex.net",68],["smartermuver.com",68],["speedostream.*",68],["sportcast.*",68],["sportshub.fan",68],["sportskart.*",68],["stream4free.live",68],["streamingcommunity.*",[68,70,112]],["sulleiman.com",68],["tamilarasan.*",68],["tamilfreemp3songs.*",68],["tamilmobilemovies.in",68],["tamilprinthd.*",68],["tapeadsenjoyer.com",[68,71,93]],["tapeadvertisement.com",[68,93]],["tapelovesads.org",[68,93]],["thewatchseries.live",68],["tnmusic.in",68],["torrentdosfilmes.*",68],["totalsportek.*",68],["travelplanspro.com",68],["tubemate.*",68],["tusfiles.com",68],["tutlehd4.com",68],["twstalker.com",68],["uploadrar.*",68],["uqload.*",68],["vegamovie.*",68],["vid-guard.com",68],["vidcloud9.*",68],["vido.*",68],["vidoo.*",68],["vidsaver.net",68],["vidspeeds.com",68],["viralitytoday.com",68],["voiranime.stream",68],["vpcxz19p.xyz",68],["vudeo.*",68],["vumoo.*",68],["watchdoctorwhoonline.com",68],["watchomovies.*",[68,109]],["watchserie.online",68],["woxikon.in",68],["www-y2mate.com",68],["yesmovies.*",68],["ylink.bid",68],["z12z0vla.*",68],["zvision.link",68],["xn-----0b4asja7ccgu2b4b0gd0edbjm2jpa1b1e9zva7a0347s4da2797e8qri.xn--1ck2e1b",68],["kickassanime.*",69],["cinego.tv",70],["dokoembed.pw",70],["ev01.to",70],["fojik.*",70],["fstream365.com",70],["fzmovies.*",70],["linkz.*",70],["minoplres.xyz",70],["mostream.us",70],["moviedokan.*",70],["myflixer.*",70],["oii.la",70],["prmovies.*",70],["readcomiconline.li",70],["s3embtaku.pro",70],["sflix2.to",70],["sportshub.stream",70],["streamblasters.*",70],["topcinema.cam",70],["webxzplay.cfd",70],["zonatmo.com",70],["animesaturn.cx",70],["filecrypt.*",70],["hunterscomics.com",70],["aniwave.uk",70],["dojing.net",71],["fuckflix.click",71],["javsubindo.com",71],["krx18.com",71],["loadx.ws",71],["mangaforfree.com",71],["pornx.to",71],["savefiles.*",[71,250]],["shavetape.cash",71],["strcloud.club",71],["strcloud.site",71],["streampoi.com",71],["strmup.to",[71,166]],["up4stream.com",[71,109]],["ups2up.fun",[71,109]],["videq.stream",71],["xmegadrive.com",71],["rubystm.com",71],["rubyvid.com",71],["rubyvidhub.com",71],["stmruby.com",71],["streamruby.com",71],["kaa.to",72],["hyhd.org",73],["bi-girl.net",74],["ftuapps.*",74],["hentaiseason.com",74],["hoodtrendspredict.com",74],["marcialhub.xyz",74],["odiadance.com",74],["osteusfilmestuga.online",74],["ragnarokscanlation.opchapters.com",74],["showflix.*",74],["swordalada.org",74],["tvappapk.com",74],["twobluescans.com",[74,75]],["varnascan.xyz",74],["fcsnew.net",76],["bibliopanda.visblog.online",77],["hallofseries.com",77],["luciferdonghua.in",77],["toursetlist.com",77],["truyentranhfull.net",77],["fcportables.com",77],["repack-games.com",77],["ibooks.to",77],["blog.tangwudi.com",77],["filecatchers.com",77],["babaktv.com",77],["sportsgamblingpodcast.com",78],["spotofteadesigns.com",78],["stacysrandomthoughts.com",78],["ssnewstelegram.com",78],["superherohype.com",[78,81]],["tablelifeblog.com",78],["thebeautysection.com",78],["thecurvyfashionista.com",78],["thefashionspot.com",78],["thegamescabin.com",78],["thenerdyme.com",78],["thenonconsumeradvocate.com",78],["theprudentgarden.com",78],["thethings.com",78],["timesnews.net",78],["topspeed.com",78],["toyotaklub.org.pl",78],["travelingformiles.com",78],["tutsnode.org",78],["viralviralvideos.com",78],["wannacomewith.com",78],["wimp.com",[78,81]],["windsorexpress.co.uk",78],["woojr.com",78],["worldoftravelswithkids.com",78],["worldsurfleague.com",78],["cheatsheet.com",79],["pwinsider.com",79],["c-span.org",80],["15min.lt",81],["247sports.com",81],["abc17news.com",81],["agrodigital.com",81],["al.com",81],["aliontherunblog.com",81],["allaboutthetea.com",81],["allmovie.com",81],["allmusic.com",81],["allthingsthrifty.com",81],["amessagewithabottle.com",81],["arstechnica.com",81],["artforum.com",81],["artnews.com",81],["audiomack.com",81],["awkward.com",81],["barcablaugranes.com",81],["barnsleychronicle.com",81],["bethcakes.com",81],["betweenenglandandiowa.com",81],["bgr.com",81],["billboard.com",81],["blazersedge.com",81],["blogher.com",81],["blu-ray.com",81],["bluegraygal.com",81],["briefeguru.de",81],["brobible.com",81],["cagesideseats.com",81],["cbsnews.com",81],["cbssports.com",[81,255]],["celiacandthebeast.com",81],["chaptercheats.com",81],["cleveland.com",81],["clickondetroit.com",81],["commercialcompetentedigitale.ro",81],["crooksandliars.com",81],["dailydot.com",81],["dailykos.com",81],["dailyvoice.com",81],["danslescoulisses.com",81],["decider.com",81],["didyouknowfacts.com",81],["dogtime.com",81],["dpreview.com",81],["ebaumsworld.com",81],["egoallstars.com",81],["eldiariony.com",81],["fark.com",81],["femestella.com",81],["flickr.com",81],["fmradiofree.com",81],["forums.hfboards.com",81],["free-power-point-templates.com",81],["freeconvert.com",81],["frogsandsnailsandpuppydogtail.com",81],["funtasticlife.com",81],["fwmadebycarli.com",81],["golfdigest.com",81],["grunge.com",81],["gulflive.com",81],["hollywoodreporter.com",81],["homeglowdesign.com",81],["honeygirlsworld.com",81],["ibtimes.co.in",81],["imgur.com",81],["indiewire.com",81],["intouchweekly.com",81],["jasminemaria.com",81],["kens5.com",81],["kion546.com",81],["knowyourmeme.com",81],["last.fm",81],["lehighvalleylive.com",81],["lettyskitchen.com",81],["lifeandstylemag.com",81],["lifeinleggings.com",81],["lizzieinlace.com",81],["localnews8.com",81],["lonestarlive.com",81],["madeeveryday.com",81],["maidenhead-advertiser.co.uk",81],["mandatory.com",81],["mardomreport.net",81],["masslive.com",81],["melangery.com",81],["miamiherald.com",81],["mmamania.com",81],["momtastic.com",81],["mostlymorgan.com",81],["motherwellmag.com",81],["musicfeeds.com.au",81],["naszemiasto.pl",81],["nationalpost.com",81],["nationalreview.com",81],["nbcsports.com",81],["news.com.au",81],["ninersnation.com",81],["nj.com",81],["nordot.app",81],["nothingbutnewcastle.com",81],["nsjonline.com",81],["nypost.com",81],["observer.com",81],["ontvtonight.com",81],["oregonlive.com",81],["pagesix.com",81],["patheos.com",81],["pennlive.com",81],["pep.ph",[81,86]],["phillyvoice.com",81],["playstationlifestyle.net",81],["puckermom.com",81],["reelmama.com",81],["rlfans.com",81],["robbreport.com",81],["rollingstone.com",81],["royalmailchat.co.uk",81],["sandrarose.com",81],["sbnation.com",81],["silive.com",81],["sheknows.com",81],["sidereel.com",81],["smartworld.it",81],["sneakernews.com",81],["sourcingjournal.com",81],["soldionline.it",81],["sport-fm.gr",81],["sportico.com",81],["stylecaster.com",81],["syracuse.com",81],["tastingtable.com",81],["techcrunch.com",81],["thecelticblog.com",[81,83]],["thedailymeal.com",81],["theflowspace.com",81],["themarysue.com",81],["tiermaker.com",81],["timesofisrael.com",81],["tiscali.cz",81],["tokfm.pl",81],["torontosun.com",81],["tvline.com",81],["usmagazine.com",81],["wallup.net",81],["weather.com",81],["worldstar.com",81],["worldstarhiphop.com",81],["wwd.com",81],["wzzm13.com",81],["yourcountdown.to",81],["automobile-catalog.com",[82,83,84]],["baseballchannel.jp",[82,83]],["forum.mobilism.me",82],["gbatemp.net",82],["gentosha-go.com",82],["hang.hu",82],["hoyme.jp",82],["motorbikecatalog.com",[82,83,84]],["pons.com",82],["wisevoter.com",82],["topstarnews.net",82],["islamicfinder.org",82],["secure-signup.net",82],["dramabeans.com",82],["dropgame.jp",[82,83]],["manta.com",82],["tportal.hr",82],["tvtropes.org",82],["convertcase.net",82],["oricon.co.jp",83],["uranai.nosv.org",83],["yakkun.com",83],["24sata.hr",83],["373news.com",83],["actugaming.net",83],["aerotrader.com",83],["alc.co.jp",83],["allthetests.com",83],["animanch.com",83],["aniroleplay.com",83],["apkmirror.com",[83,186]],["areaconnect.com",83],["as-web.jp",83],["atvtrader.com",83],["aucfree.com",83],["autoby.jp",83],["autoc-one.jp",83],["autofrage.net",83],["bab.la",83],["babla.*",83],["bien.hu",83],["boredpanda.com",83],["bunshun.jp",83],["calculatorsoup.com",83],["carscoops.com",83],["cesoirtv.com",83],["chanto.jp.net",83],["cinetrafic.fr",83],["cocokara-next.com",83],["collinsdictionary.com",83],["commercialtrucktrader.com",83],["computerfrage.net",83],["crosswordsolver.com",83],["cruciverba.it",83],["cults3d.com",83],["culturequizz.com",83],["cycletrader.com",83],["daily.co.jp",83],["dailynewshungary.com",83],["dallashoopsjournal.com",83],["dayspedia.com",83],["dictionary.cambridge.org",83],["dictionnaire.lerobert.com",83],["dnevno.hr",83],["dreamchance.net",83],["drweil.com",83],["dziennik.pl",83],["ecranlarge.com",83],["eigachannel.jp",83],["equipmenttrader.com",83],["ev-times.com",83],["finanzfrage.net",83],["footballchannel.jp",83],["forsal.pl",83],["freemcserver.net",83],["futabanet.jp",83],["fxstreet-id.com",83],["fxstreet-vn.com",83],["fxstreet.*",83],["game8.jp",83],["gamewith.jp",83],["gardeningsoul.com",83],["gazetaprawna.pl",83],["gesundheitsfrage.net",83],["gifu-np.co.jp",83],["gigafile.nu",83],["globalrph.com",83],["golf-live.at",83],["grapee.jp",83],["gutefrage.net",83],["happymoments.lol",83],["hb-nippon.com",83],["heureka.cz",83],["horairesdouverture24.fr",83],["hotcopper.co.nz",83],["hotcopper.com.au",83],["idokep.hu",83],["indiatimes.com",83],["infor.pl",83],["iza.ne.jp",83],["j-cast.com",83],["j-town.net",83],["j7p.jp",83],["jablickar.cz",83],["javatpoint.com",83],["jiji.com",83],["jikayosha.jp",83],["judgehype.com",83],["kinmaweb.jp",83],["km77.com",83],["kobe-journal.com",83],["kreuzwortraetsel.de",83],["kurashinista.jp",83],["kurashiru.com",83],["kyoteibiyori.com",83],["lacuarta.com",83],["laleggepertutti.it",83],["langenscheidt.com",83],["laposte.net",83],["lawyersgunsmoneyblog.com",83],["ldoceonline.com",83],["listentotaxman.com",83],["livenewschat.eu",83],["luremaga.jp",83],["mafab.hu",83],["mahjongchest.com",83],["mainichi.jp",83],["maketecheasier.com",[83,84]],["malaymail.com",83],["mamastar.jp",83],["mathplayzone.com",83],["meteo60.fr",83],["midhudsonnews.com",83],["minesweeperquest.com",83],["minkou.jp",83],["modhub.us",83],["modsfire.com",83],["moin.de",83],["motorradfrage.net",83],["motscroises.fr",83],["movie-locations.com",83],["muragon.com",83],["nana-press.com",83],["natalie.mu",83],["nationaltoday.com",83],["nbadraft.net",83],["newatlas.com",83],["news.zerkalo.io",83],["newsinlevels.com",83],["newsweekjapan.jp",83],["niketalk.com",83],["nikkan-gendai.com",83],["nlab.itmedia.co.jp",83],["notebookcheck.*",83],["notebookcheck-cn.com",83],["notebookcheck-hu.com",83],["notebookcheck-ru.com",83],["notebookcheck-tr.com",83],["nouvelobs.com",83],["nyitvatartas24.hu",83],["oeffnungszeitenbuch.de",83],["onlineradiobox.com",83],["operawire.com",83],["optionsprofitcalculator.com",83],["oraridiapertura24.it",83],["oxfordlearnersdictionaries.com",83],["palabr.as",83],["pashplus.jp",83],["persoenlich.com",83],["petitfute.com",83],["play-games.com",83],["popdaily.com.tw",83],["powerpyx.com",83],["pptvhd36.com",83],["profitline.hu",83],["programme-tv.net",83],["puzzlegarage.com",83],["pwctrader.com",83],["quefaire.be",83],["radio-australia.org",83],["radio-osterreich.at",83],["raetsel-hilfe.de",83],["raider.io",83],["ranking.net",83],["references.be",83],["reisefrage.net",83],["relevantmagazine.com",83],["reptilesmagazine.com",83],["roleplayer.me",83],["rostercon.com",83],["samsungmagazine.eu",83],["sankei.com",83],["sanspo.com",83],["scribens.com",83],["scribens.fr",83],["slashdot.org",83],["snowmobiletrader.com",83],["soccerdigestweb.com",83],["solitairehut.com",83],["sourceforge.net",83],["southhemitv.com",83],["sportalkorea.com",83],["sportlerfrage.net",83],["statecollege.com",83],["steamidfinder.com",83],["syosetu.com",83],["szamoldki.hu",83],["talkwithstranger.com",83],["tbs.co.jp",83],["techdico.com",83],["the-crossword-solver.com",83],["thedigestweb.com",83],["traicy.com",83],["transparentcalifornia.com",83],["transparentnevada.com",83],["trilltrill.jp",83],["tunebat.com",83],["tvtv.ca",83],["tvtv.us",83],["tweaktown.com",83],["twn.hu",83],["tyda.se",83],["ufret.jp",83],["universalis.fr",83],["uptodown.com",83],["uscreditcardguide.com",83],["verkaufsoffener-sonntag.com",83],["vimm.net",83],["wamgame.jp",83],["watchdocumentaries.com",83],["wattedoen.be",83],["webdesignledger.com",83],["wetteronline.de",83],["wfmz.com",83],["wieistmeineip.*",83],["winfuture.de",83],["word-grabber.com",83],["worldjournal.com",83],["wort-suchen.de",83],["woxikon.*",83],["young-machine.com",83],["yugioh-starlight.com",83],["yutura.net",83],["zagreb.info",83],["zakzak.co.jp",83],["2chblog.jp",83],["2monkeys.jp",83],["46matome.net",83],["akb48glabo.com",83],["akb48matomemory.com",83],["alfalfalfa.com",83],["all-nationz.com",83],["anihatsu.com",83],["aqua2ch.net",83],["blog.esuteru.com",83],["blog.livedoor.jp",83],["blog.jp",83],["blogo.jp",83],["chaos2ch.com",83],["choco0202.work",83],["crx7601.com",83],["danseisama.com",83],["dareda.net",83],["digital-thread.com",83],["doorblog.jp",83],["exawarosu.net",83],["fgochaldeas.com",83],["football-2ch.com",83],["gekiyaku.com",83],["golog.jp",83],["hacchaka.net",83],["heartlife-matome.com",83],["liblo.jp",83],["fesoku.net",83],["fiveslot777.com",83],["gamejksokuhou.com",83],["girlsreport.net",83],["girlsvip-matome.com",83],["grasoku.com",83],["gundamlog.com",83],["honyaku-channel.net",83],["ikarishintou.com",83],["imas-cg.net",83],["imihu.net",83],["inutomo11.com",83],["itainews.com",83],["itaishinja.com",83],["jin115.com",83],["jisaka.com",83],["jnews1.com",83],["jumpsokuhou.com",83],["jyoseisama.com",83],["keyakizaka46matomemory.net",83],["kidan-m.com",83],["kijoden.com",83],["kijolariat.net",83],["kijolifehack.com",83],["kijomatomelog.com",83],["kijyokatu.com",83],["kijyomatome.com",83],["kijyomatome-ch.com",83],["kijyomita.com",83],["kirarafan.com",83],["kitimama-matome.net",83],["kitizawa.com",83],["konoyubitomare.jp",83],["kotaro269.com",83],["kyousoku.net",83],["ldblog.jp",83],["livedoor.biz",83],["livedoor.blog",83],["majikichi.com",83],["matacoco.com",83],["matomeblade.com",83],["matomelotte.com",83],["matometemitatta.com",83],["mojomojo-licarca.com",83],["morikinoko.com",83],["nandemo-uketori.com",83],["netatama.net",83],["news-buzz1.com",83],["news30over.com",83],["nishinippon.co.jp",83],["nmb48-mtm.com",83],["norisoku.com",83],["npb-news.com",83],["ocsoku.com",83],["okusama-kijyo.com",83],["onecall2ch.com",83],["onihimechan.com",83],["orusoku.com",83],["otakomu.jp",83],["otoko-honne.com",83],["oumaga-times.com",83],["outdoormatome.com",83],["pachinkopachisro.com",83],["paranormal-ch.com",83],["recosoku.com",83],["s2-log.com",83],["saikyo-jump.com",83],["shuraba-matome.com",83],["ske48matome.net",83],["squallchannel.com",83],["sukattojapan.com",83],["sumaburayasan.com",83],["sutekinakijo.com",83],["usi32.com",83],["uwakich.com",83],["uwakitaiken.com",83],["vault76.info",83],["vipnews.jp",83],["vippers.jp",83],["vipsister23.com",83],["vtubernews.jp",83],["watarukiti.com",83],["world-fusigi.net",83],["zakuzaku911.com",83],["zch-vip.com",83],["12thmanrising.com",83],["aroundthefoghorn.com",83],["arrowheadaddict.com",83],["badgerofhonor.com",83],["bamahammer.com",83],["beargoggleson.com",83],["beyondtheflag.com",83],["blackandteal.com",83],["blogredmachine.com",83],["bluemanhoop.com",83],["boltbeat.com",83],["bosoxinjection.com",83],["buffalowdown.com",83],["caneswarning.com",83],["catcrave.com",83],["chopchat.com",83],["climbingtalshill.com",83],["cubbiescrib.com",83],["dailyknicks.com",83],["dairylandexpress.com",83],["dawindycity.com",83],["dawnofthedawg.com",83],["detroitjockcity.com",83],["dodgersway.com",83],["ebonybird.com",83],["fansided.com",83],["gbmwolverine.com",83],["gmenhq.com",83],["hailfloridahail.com",83],["hardwoodhoudini.com",83],["horseshoeheroes.com",83],["housethathankbuilt.com",83],["huskercorner.com",83],["insidetheiggles.com",83],["jaysjournal.com",83],["justblogbaby.com",83],["kckingdom.com",83],["kingjamesgospel.com",83],["lakeshowlife.com",83],["lombardiave.com",83],["motorcitybengals.com",83],["musketfire.com",83],["nflspinzone.com",83],["ninernoise.com",83],["nugglove.com",83],["phinphanatic.com",83],["pistonpowered.com",83],["predominantlyorange.com",83],["ramblinfan.com",83],["redbirdrants.com",83],["reviewingthebrew.com",83],["riggosrag.com",83],["ripcityproject.com",83],["risingapple.com",83],["rumbunter.com",83],["scarletandgame.com",83],["section215.com",83],["sidelionreport.com",83],["slapthesign.com",83],["sodomojo.com",83],["stillcurtain.com",83],["stormininnorman.com",83],["stripehype.com",83],["thatballsouttahere.com",83],["thejetpress.com",83],["thelandryhat.com",83],["thepewterplank.com",83],["thesmokingcuban.com",83],["thevikingage.com",83],["thunderousintentions.com",83],["valleyofthesuns.com",83],["whodatdish.com",83],["yanksgoyard.com",83],["interfootball.co.kr",84],["a-ha.io",84],["cboard.net",84],["jjang0u.com",84],["joongdo.co.kr",84],["viva100.com",84],["gamingdeputy.com",84],["alle-tests.nl",84],["tweaksforgeeks.com",84],["m.inven.co.kr",84],["mlbpark.donga.com",84],["meconomynews.com",84],["brandbrief.co.kr",84],["motorgraph.com",84],["bleepingcomputer.com",85],["pravda.com.ua",85],["ap7am.com",86],["cinema.com.my",86],["dolldivine.com",86],["giornalone.it",86],["iplocation.net",86],["jamaicajawapos.com",86],["jutarnji.hr",86],["kompasiana.com",86],["mediaindonesia.com",86],["niice-woker.com",86],["slobodnadalmacija.hr",86],["upmedia.mg",86],["mentalfloss.com",87],["bigwarp.cc",88],["3minx.com",89],["555fap.com",89],["ai18.pics",89],["anime-jav.com",89],["blackwidof.org",89],["chinese-pics.com",89],["cn-av.com",89],["cnpics.org",89],["cnxx.me",89],["cosplay-xxx.com",89],["cosplay18.pics",89],["fc2ppv.stream",89],["fikfok.net",89],["gofile.download",89],["hentai-sub.com",89],["hentai4f.com",89],["hentaicovid.com",89],["hentaipig.com",89],["hentaixnx.com",89],["idol69.net",89],["javball.com",89],["javbee.*",89],["javring.com",89],["javsunday.com",89],["javtele.net",89],["kin8-av.com",89],["kin8-jav.com",89],["kr-av.com",89],["ovabee.com",89],["pig69.com",89],["porn-pig.com",89],["porn4f.org",89],["sweetie-fox.com",89],["xcamcovid.com",89],["xxpics.org",89],["hentaivost.fr",90],["jelonka.com",91],["isgfrm.com",92],["advertisertape.com",93],["watchadsontape.com",93],["vosfemmes.com",94],["voyeurfrance.net",94],["hyundaitucson.info",95],["exambd.net",96],["cgtips.org",97],["freewebcart.com",98],["freemagazines.top",98],["siamblockchain.com",98],["emuenzen.de",99],["kickass.*",100],["unblocked.id",102],["listendata.com",103],["7xm.xyz",103],["fastupload.io",103],["azmath.info",103],["wouterplanet.com",104],["xenvn.com",105],["4kporn.xxx",106],["androidacy.com",107],["4porn4.com",108],["bestpornflix.com",109],["freeroms.com",109],["andhrafriends.com",109],["723qrh1p.fun",109],["98zero.com",110],["mediaset.es",110],["hwbusters.com",110],["beatsnoop.com",111],["fetchpik.com",111],["hackerranksolution.in",111],["camsrip.com",111],["file.org",111],["btcbunch.com",113],["teachoo.com",[114,115]],["mafiatown.pl",116],["bitcotasks.com",117],["hilites.today",118],["udvl.com",119],["www.chip.de",[120,121,122,123]],["topsporter.net",124],["sportshub.to",124],["myanimelist.net",125],["unofficialtwrp.com",126],["codec.kyiv.ua",126],["kimcilonlyofc.com",126],["bitcosite.com",127],["bitzite.com",127],["teluguflix.*",128],["hacoos.com",129],["watchhentai.net",130],["hes-goals.io",130],["pkbiosfix.com",130],["casi3.xyz",130],["zefoy.com",131],["mailgen.biz",132],["tempinbox.xyz",132],["vidello.net",133],["newscon.org",134],["yunjiema.top",134],["pcgeeks-games.com",134],["resizer.myct.jp",135],["gametohkenranbu.sakuraweb.com",136],["jisakuhibi.jp",137],["rank1-media.com",137],["lifematome.blog",138],["fm.sekkaku.net",139],["dvdrev.com",140],["betweenjpandkr.blog",141],["nft-media.net",142],["ghacks.net",143],["khoaiphim.com",145],["haafedk2.com",146],["jovemnerd.com.br",147],["totalcsgo.com",148],["manysex.com",149],["gaminginfos.com",150],["tinxahoivn.com",151],["m.4khd.com",152],["westmanga.*",152],["automoto.it",153],["fordownloader.com",154],["codelivly.com",155],["tchatche.com",156],["cryptoearns.com",156],["lordchannel.com",157],["novelhall.com",158],["bagi.co.in",159],["keran.co",159],["biblestudytools.com",160],["christianheadlines.com",160],["ibelieve.com",160],["kuponigo.com",161],["inxxx.com",162],["bemyhole.com",162],["embedwish.com",163],["jenismac.com",164],["vxetable.cn",165],["luluvid.com",166],["daddylive1.*",166],["esportivos.*",166],["instream.pro",166],["poscitechs.*",166],["powerover.online",166],["sportea.link",166],["ustream.pro",166],["animeshqip.site",166],["apkship.shop",166],["filedot.to",166],["hdstream.one",166],["kingstreamz.site",166],["live.fastsports.store",166],["livesnow.me",166],["livesports4u.pw",166],["nuxhallas.click",166],["papahd.info",166],["rgshows.me",166],["sportmargin.live",166],["sportmargin.online",166],["sportsloverz.xyz",166],["supertipzz.online",166],["ultrastreamlinks.xyz",166],["webmaal.cfd",166],["wizistreamz.xyz",166],["educ4m.com",166],["fromwatch.com",166],["visualnewshub.com",166],["donghuaworld.com",167],["letsdopuzzles.com",168],["rediff.com",169],["igay69.com",170],["dzapk.com",171],["darknessporn.com",172],["familyporner.com",172],["freepublicporn.com",172],["pisshamster.com",172],["punishworld.com",172],["xanimu.com",172],["tainio-mania.online",173],["eroticmoviesonline.me",174],["series9movies.com",174],["teleclub.xyz",175],["ecamrips.com",176],["showcamrips.com",176],["tucinehd.com",177],["uyeshare.cc",177],["9animetv.to",178],["qiwi.gg",179],["jornadaperfecta.com",180],["sousou-no-frieren.com",181],["unite-guide.com",183],["thebullspen.com",184],["receitasdaora.online",185],["hiraethtranslation.com",187],["all3do.com",188],["d-s.io",188],["d0000d.com",188],["d000d.com",188],["d0o0d.com",188],["do0od.com",188],["do7go.com",188],["doods.*",188],["doodstream.*",188],["dooodster.com",188],["doply.net",188],["ds2play.com",188],["ds2video.com",188],["vidply.com",188],["vide0.net",188],["vvide0.com",188],["xfreehd.com",189],["freethesaurus.com",190],["thefreedictionary.com",190],["dexterclearance.com",191],["x86.co.kr",192],["onlyfaucet.com",193],["x-x-x.tube",194],["fdownloader.net",195],["thehackernews.com",196],["mielec.pl",197],["treasl.com",198],["mrbenne.com",199],["sportsonline.si",200],["fiuxy2.co",201],["animeunity.to",202],["tokopedia.com",203],["remixsearch.net",204],["remixsearch.es",204],["onlineweb.tools",204],["sharing.wtf",204],["2024tv.ru",205],["modrinth.com",206],["curseforge.com",206],["xnxxcom.xyz",207],["sportsurge.net",208],["joyousplay.xyz",208],["quest4play.xyz",[208,210]],["moneycontrol.com",209],["cookiewebplay.xyz",210],["ilovetoplay.xyz",210],["streamcaster.live",210],["weblivehdplay.ru",210],["nontongo.win",211],["m9.news",212],["callofwar.com",213],["secondhandsongs.com",214],["nohost.one",215],["send.cm",216],["send.now",216],["3rooodnews.net",217],["xxxbfvideo.net",218],["filmy4wap.co.in",219],["filmy4waps.org",219],["gameshop4u.com",220],["regenzi.site",220],["historicaerials.com",221],["handirect.fr",222],["fsiblog3.club",223],["kamababa.desi",223],["sat-sharing.com",223],["getfiles.co.uk",224],["genelify.com",225],["dhtpre.com",226],["xbaaz.com",227],["lineupexperts.com",229],["fearmp4.ru",230],["appnee.com",231],["buffsports.*",232],["fbstreams.*",232],["wavewalt.me",[232,248]],["pornoxo.com",233],["m.shuhaige.net",234],["streamingnow.mov",235],["thesciencetoday.com",236],["sportnews.to",236],["ghbrisk.com",238],["iplayerhls.com",238],["bacasitus.com",239],["katoikos.world",239],["abstream.to",240],["pawastreams.pro",241],["rebajagratis.com",242],["tv.latinlucha.es",242],["fetcheveryone.com",243],["reviewdiv.com",244],["laurelberninteriors.com",245],["godlike.com",246],["godlikeproductions.com",246],["bestsportslive.org",247],["alexsports.*>>",248],["btvsports.my>>",248],["cr7-soccer.store>>",248],["e2link.link>>",248],["fsportshd.xyz>>",248],["kakarotfoot.ru>>",248],["pelotalibrevivo.net>>",248],["powerover.site>>",248],["redditsoccerstreams.name>>",248],["sportstohfa.online>>",248],["sportzonline.site>>",248],["streamshunters.eu>>",248],["totalsportek1000.com>>",248],["worldsports.*>>",248],["7fractals.icu",248],["allevertakstream.space",248],["brainknock.net",248],["btvsports.my",248],["capo6play.com",248],["capoplay.net",248],["cdn256.xyz",248],["courseleader.net",248],["cr7-soccer.store",248],["dropbang.net",248],["e2link.link",248],["hornpot.net",248],["fsportshd.xyz",248],["ihdstreams.*",248],["kakarotfoot.ru",248],["meltol.net",248],["nativesurge.net",248],["powerover.site",248],["snapinstadownload.xyz",248],["sportstohfa.online",248],["sportzonline.site",248],["stellarthread.com",248],["streamshunters.eu",248],["totalsportek1000.com",248],["voodc.com",248],["worldsports.*",248],["ziggogratis.site",248],["bestreamsports.org",249],["streamhls.to",251],["xmalay1.net",252],["letemsvetemapplem.eu",253],["pc-builds.com",254],["emoji.gg",256],["pfps.gg",257],["live4all.net",258],["pokemon-project.com",259],["moviesonlinefree.*",260],["fileszero.com",261],["viralharami.com",261],["wstream.cloud",261],["bmamag.com",262],["bmacanberra.wpcomstaging.com",262],["cinemastervip.com",263],["mmsbee42.com",264],["mmsmasala.com",264],["andrenalynrushplay.cfd",265],["fnjplay.xyz",265],["porn4fans.com",267],["kaliscan.io",268],["webnoveltranslations.com",269],["cefirates.com",270],["comicleaks.com",270],["tapmyback.com",270],["ping.gg",270],["nookgaming.com",270],["creatordrop.com",270],["bitdomain.biz",270],["fort-shop.kiev.ua",270],["accuretawealth.com",270],["resourceya.com",270],["tracktheta.com",270],["adaptive.marketing",270],["camberlion.com",270],["trybawaryjny.pl",270],["segops.madisonspecs.com",270],["stresshelden-coaching.de",270],["controlconceptsusa.com",270],["ryaktive.com",270],["tip.etip-staging.etip.io",270],["future-fortune.com",271],["furucombo.app",271],["bolighub.dk",271],["intercity.technology",272],["freelancer.taxmachine.be",272],["adria.gg",272],["fjlaboratories.com",272],["abhijith.page",272],["helpmonks.com",272],["dataunlocker.com",273],["proboards.com",274],["winclassic.net",274],["farmersjournal.ie",275],["zorroplay.xyz",277]]);
const exceptionsMap = new Map([["chatango.com",[8]],["twitter.com",[8]],["youtube.com",[8]]]);
const hasEntities = true;
const hasAncestors = true;

const collectArgIndices = (hn, map, out) => {
    let argsIndices = map.get(hn);
    if ( argsIndices === undefined ) { return; }
    if ( typeof argsIndices !== 'number' ) {
        for ( const argsIndex of argsIndices ) {
            out.add(argsIndex);
        }
    } else {
        out.add(argsIndices);
    }
};

const indicesFromHostname = (hostname, suffix = '') => {
    const hnParts = hostname.split('.');
    const hnpartslen = hnParts.length;
    if ( hnpartslen === 0 ) { return; }
    for ( let i = 0; i < hnpartslen; i++ ) {
        const hn = `${hnParts.slice(i).join('.')}${suffix}`;
        collectArgIndices(hn, hostnamesMap, todoIndices);
        collectArgIndices(hn, exceptionsMap, tonotdoIndices);
    }
    if ( hasEntities ) {
        const n = hnpartslen - 1;
        for ( let i = 0; i < n; i++ ) {
            for ( let j = n; j > i; j-- ) {
                const en = `${hnParts.slice(i,j).join('.')}.*${suffix}`;
                collectArgIndices(en, hostnamesMap, todoIndices);
                collectArgIndices(en, exceptionsMap, tonotdoIndices);
            }
        }
    }
};

const entries = (( ) => {
    const docloc = document.location;
    const origins = [ docloc.origin ];
    if ( docloc.ancestorOrigins ) {
        origins.push(...docloc.ancestorOrigins);
    }
    return origins.map((origin, i) => {
        const beg = origin.lastIndexOf('://');
        if ( beg === -1 ) { return; }
        const hn = origin.slice(beg+3)
        const end = hn.indexOf(':');
        return { hn: end === -1 ? hn : hn.slice(0, end), i };
    }).filter(a => a !== undefined);
})();
if ( entries.length === 0 ) { return; }

const todoIndices = new Set();
const tonotdoIndices = new Set();

indicesFromHostname(entries[0].hn);
if ( hasAncestors ) {
    for ( const entry of entries ) {
        if ( entry.i === 0 ) { continue; }
        indicesFromHostname(entry.hn, '>>');
    }
}

// Apply scriplets
for ( const i of todoIndices ) {
    if ( tonotdoIndices.has(i) ) { continue; }
    try { removeNodeText(...argsList[i]); }
    catch { }
}

/******************************************************************************/

// End of local scope
})();

void 0;
